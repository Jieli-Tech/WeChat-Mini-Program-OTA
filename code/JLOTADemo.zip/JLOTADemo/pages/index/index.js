// index.js
// 获取应用实例

// import * as JLBle from "../../lib/ble/JLBluetooth"
const JLBle = require('../../lib/JLOta_v1.0.0.js')

const app = getApp()
let advTime = 0;

let version = "0.0.8"

Page({
  data: {
    devices: [],
    file: null,
    otaMsg: '',
    showOta: false,
    otaProgress: false,
    fileSize: 0,
    fileCrc: 0,

  },
  // 事件处理函数
  deviceClick(e) {
    let device = e.currentTarget.dataset.item;


    if (device.status != 1) {
      if (JLBle.getConnectedDevice()) {
        wx.showToast({
          title: '请先断开已连接的设备',
          icon: 'none'
        })
        return;
      }
      JLBle.connect(device)
      wx.showLoading({
        title: '连接中',
      })
    } else if (device.status == 1) {
      wx.showModal({
        title: '提示',
        content: '是否要断开该设备',
        success(res) {
          if (res.confirm) {
            JLBle.disconnect()
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
    }
  },



  hidedialog: function (e) {

  },

  upgrade: function (e) {
    let device = e.currentTarget.dataset.item;
    if (device.status != 1) {
      wx.showToast({
        title: '设备未连接',
        icon: 'none'
      })
      return;
    }

    if (!this.upgradeData) {
      wx.showToast({
        title: '请先选择文件',
        icon: 'none'
      })
      return
    }

    JLBle.startOta(this.upgradeData, {
      onMsg: () => {

      },

      onStart: () => {
        this.setData({
          showOta: true
        })
      },

      onProgress: res => {
        let msg = res.type == 0x01 ? '发送sdk升级数据' : '发送uboot升级数据'
        this.setData({
          otaProgress: res.progress,
          otaMsg: msg
        })
      },
      onFinish: () => {
        this.setData({
          showOta: false
        })
        wx.showModal({
          title: '提示',
          content: '升级成功',

        })
      },
      onError: e => {
        console.error("升级失败")
        console.error(e)
        this.setData({
          showOta: false,
          otaProgress: 0,
        })
        wx.showModal({
          title: '提示',
          content: '升级失败:' + e.msg,
        })
      }
    })
  },
  onLoad() {

    JLBle.init()

    let callback = {}
    callback.onFound = this.onFound
    callback.onConnection = this.onConnection
    callback.onCmdReceive = this.onCmdReceive
    this.callback = callback
    JLBle.addCallback(callback)

    console.error("version------->"+version)
  },

  onUnload: function () {
    JLBle.removeCallback(this.callback)
  },

  onFound: function (devices) {
    let connectedDevice = JLBle.getConnectedDevice()
    devices.forEach(it => {
      if (connectedDevice) {
        it.status = (connectedDevice.deviceId == it.deviceId) ? 1 : 0
      } else {
        it.status = 0;
      }
    })

    this.setData({
      devices: devices
    })
  },

  onConnection: function (e) {
    if (e.status == JLBle.CONNECT_STATUS_CONNECTED) {
      wx.hideLoading({
        success: (res) => {},
      })
      wx.showToast({
        title: '连接成功',
        icon: 'none'
      })
      this.onFound(this.data.devices)
    } else if (e.status == JLBle.CONNECT_STATUS_DISCONNECTED) {
      wx.showToast({
        title: '连接已断开',
        icon: 'none'
      })
      this.onFound(this.data.devices)
    } else if (e.status == JLBle.CONNECT_STATUS_FAILED) {
      wx.hideLoading({
        success: (res) => {},
      })
      wx.showToast({
        title: '连接失败',
        icon: 'none'
      })

    }

  },


  onCmdReceive: function (cmd) {

    if (cmd.opCode == 0xC2) {
      console.error("收到推送通知 --》" + JSON.stringify(cmd))
      //因为发送关闭adv命令会触发一次C2命令，所以做一下技术，
      if (advTime > 2) {
        advTime = 0;
        JLBle.openOrCloseAdvInfoUpdate(false, null)
      } else {
        advTime = advTime + 1;
      }

    }

  },

  scan: function (e) {
    //Android平台检测是否有开启位置权限，
    let info = wx.getSystemInfoSync()
    console.error(info)
    //检测是否有位置权限
    if (info.platform == "android" && !info.locationAuthorized) {
      wx.getLocation({
        altitude: true,
        success: res => {
          this.scan(e)
        },
        fail: e => {
          wx.showToast({
            title: e.errMsg,
            icon: 'none'
          })
        }
      })
      return
    }

    //检测是否打开gps位置开关
    if (info.platform == "android" && !info.locationEnabled) {
      wx.showToast({
        title: '请打开位置信息(GPS)',
        icon: 'none'
      })
      return
    }

    JLBle.startScan({
      success: res => {},
      fail: e => {
        console.error(e)
        if (e.errCode && e.errCode == 10001) {
          wx.showToast({
            title: '蓝牙未打开',
            icon: 'none'
          })
        } else {
          wx.showToast({
            title: '发现设备失败',
            icon: 'none'
          })
        }

      }
    })


  },

  readFile: function (file) {
    let fs = wx.getFileSystemManager()
    let path = file.path;

    let fd = fs.openSync({
      filePath: path
    })
    let uint8 = new Uint8Array(file.size);
    fs.read({
      fd: fd,
      arrayBuffer: uint8.buffer,
      length: file.size,
      success: res => {
        let crc = 0;
        uint8.forEach(it => {
          crc += it;
        })
        this.setData({
          file: file,
          fileSize: file.size,
          fileCrc: crc
        })

        this.upgradeData = uint8
        JLBle.log("------------读取文件成功------------")
      },
      fail: e => {
        wx.showToast({
          title: '文件读取失败',
          icon: 'none'
        })
      }
    })
  },

  choseFile: function (e) {
    wx.chooseMessageFile({
      count: 1,
      type: 'file',
      success: res => {
        let file = res.tempFiles[0];
        this.readFile(file)
      },
      fail: e => {
        console.error(e)
      }
    })
  },

  getTargetInfo: function (e) {
    JLBle.getTargetInfo(0x01 << 0x011, null)
  },

})